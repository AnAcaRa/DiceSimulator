import kivy
kivy.require(kivy.__version__)
import random
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.image import Image

class DiceSimulator(App):

    def build(self):
        def callback(instance):
            dice_num = random.randint(1, 6)
            dice_filename = 'dice' + str(dice_num) + ".png"
            print(dice_filename)
            dice_image.source = dice_filename
            
        self.title = 'Dice Simulator'
        layout = BoxLayout(orientation='vertical')
        roll_button = Button(text='Roll')
        roll_button.bind(on_press=callback)
        layout.add_widget(roll_button)
        dice_image = Image(source='')
        layout.add_widget(dice_image)
        return layout

DiceSimulator().run()
